import 'package:flutter/material.dart';

class AppColors {
  static const primary = Color(0xFF00C9F7); // błękit
  static const primaryDark = Color(0xFF007BC7); // ciemny niebieski
  static const accent = Color(0xFF008FCC);
}
